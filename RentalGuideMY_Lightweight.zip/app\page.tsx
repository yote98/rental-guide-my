"use client"

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { Calculator, ShieldCheck, BarChart3, TrendingUp, Package, Wifi, Truck, Home, Star, ArrowRight, CheckCircle, Sparkles, Zap, Brain, Target } from 'lucide-react'
import QuickCheckForm from '@/components/QuickCheckForm'

export default function HomePage() {
  const [isVisible, setIsVisible] = useState(false)
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setIsVisible(true)
    
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY })
    }
    
    window.addEventListener('mousemove', handleMouseMove)
    return () => window.removeEventListener('mousemove', handleMouseMove)
  }, [])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 relative overflow-hidden">
      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div 
          className="absolute w-96 h-96 bg-blue-500/10 rounded-full blur-3xl animate-pulse"
          style={{
            left: mousePosition.x - 200,
            top: mousePosition.y - 200,
            transition: 'all 0.3s ease-out'
          }}
        />
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-indigo-500/10 rounded-full blur-2xl animate-bounce" />
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl animate-pulse" />
      </div>

      {/* Header */}
      <header className="bg-black/20 backdrop-blur-xl border-b border-white/10 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/25 animate-pulse">
                <Brain className="h-6 w-6 text-white" />
              </div>
              <span className="text-2xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-400 bg-clip-text text-transparent">
                Rental Guide MY
              </span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <Link href="/" className="text-white/80 hover:text-cyan-400 transition-all duration-300 hover:scale-105 relative group">
                <span className="relative z-10">Quick Check</span>
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-lg scale-0 group-hover:scale-100 transition-transform duration-300" />
              </Link>
              <Link href="/verify" className="text-white/80 hover:text-cyan-400 transition-all duration-300 hover:scale-105 relative group">
                <span className="relative z-10">Verify</span>
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-lg scale-0 group-hover:scale-100 transition-transform duration-300" />
              </Link>
              <Link href="/compare" className="text-white/80 hover:text-cyan-400 transition-all duration-300 hover:scale-105 relative group">
                <span className="relative z-10">Compare</span>
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-lg scale-0 group-hover:scale-100 transition-transform duration-300" />
              </Link>
              <Link href="/services" className="text-white/80 hover:text-cyan-400 transition-all duration-300 hover:scale-105 relative group">
                <span className="relative z-10">Services</span>
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-lg scale-0 group-hover:scale-100 transition-transform duration-300" />
              </Link>
              <Link href="/trends" className="text-white/80 hover:text-cyan-400 transition-all duration-300 hover:scale-105 relative group">
                <span className="relative z-10">Trends</span>
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-lg scale-0 group-hover:scale-100 transition-transform duration-300" />
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section ref={heroRef} className="relative py-32 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center relative z-10">
            {/* Floating Elements */}
            <div className="absolute top-10 left-10 w-4 h-4 bg-cyan-400 rounded-full animate-ping opacity-75" />
            <div className="absolute top-20 right-20 w-3 h-3 bg-blue-400 rounded-full animate-pulse" />
            <div className="absolute bottom-20 left-1/4 w-2 h-2 bg-indigo-400 rounded-full animate-bounce" />
            
            <div className="inline-flex items-center space-x-2 mb-6 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 backdrop-blur-sm border border-white/20 rounded-full px-6 py-3">
              <Sparkles className="h-5 w-5 text-cyan-400 animate-spin" />
              <span className="text-cyan-300 font-medium">Powered by Advanced AI</span>
              <Zap className="h-4 w-4 text-yellow-400 animate-pulse" />
            </div>
            
            <h1 className={`text-5xl md:text-7xl font-black mb-8 transition-all duration-1500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}>
              <span className="bg-gradient-to-r from-white via-cyan-200 to-blue-200 bg-clip-text text-transparent">
                Next-Gen Rental
              </span>
              <br />
              <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-400 bg-clip-text text-transparent animate-pulse">
                Intelligence
              </span>
            </h1>
            
            <p className={`text-xl md:text-2xl text-white/80 mb-12 max-w-4xl mx-auto leading-relaxed transition-all duration-1500 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}>
              Protect yourself from misleading listings with{' '}
              <span className="text-cyan-400 font-semibold">AI-powered verification</span>, 
              real-time market analysis, and comprehensive rental solutions for{' '}
              <span className="text-blue-400 font-semibold">KL & Selangor</span>.
            </p>
            
            <div className={`flex flex-col sm:flex-row gap-6 justify-center transition-all duration-1500 delay-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-12'}`}>
              <Link href="/" className="group relative inline-flex items-center justify-center px-8 py-4 text-lg font-semibold text-white bg-gradient-to-r from-cyan-500 to-blue-600 rounded-2xl shadow-2xl shadow-cyan-500/25 hover:shadow-cyan-500/40 transform hover:scale-105 transition-all duration-300 overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                <Calculator className="relative z-10 mr-3 h-6 w-6" />
                <span className="relative z-10">Get Instant Estimate</span>
                <ArrowRight className="relative z-10 ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform duration-300" />
              </Link>
              
              <Link href="/verify" className="group relative inline-flex items-center justify-center px-8 py-4 text-lg font-semibold text-cyan-400 bg-white/10 backdrop-blur-sm border border-cyan-400/30 rounded-2xl hover:bg-white/20 transform hover:scale-105 transition-all duration-300">
                <ShieldCheck className="mr-3 h-6 w-6" />
                <span>Verify Listing</span>
                <Target className="ml-2 h-5 w-5 group-hover:rotate-12 transition-transform duration-300" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Check Form */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-slate-900/50 to-slate-800/50 backdrop-blur-sm">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <div className="inline-flex items-center space-x-2 mb-6 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 backdrop-blur-sm border border-cyan-400/20 rounded-full px-6 py-3">
              <Brain className="h-5 w-5 text-cyan-400 animate-pulse" />
              <span className="text-cyan-300 font-medium">AI-Powered Analysis</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-black mb-6 bg-gradient-to-r from-white via-cyan-200 to-blue-200 bg-clip-text text-transparent">
              Get Your Rental Estimate
            </h2>
            <p className="text-xl text-white/70 max-w-3xl mx-auto">
              Enter your property details to get an AI-powered rental price estimate with comparable properties
            </p>
          </div>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-3xl blur-xl" />
            <div className="relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-8 shadow-2xl">
              <QuickCheckForm />
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-24 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-slate-800/50 to-slate-900/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <div className="inline-flex items-center space-x-2 mb-6 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 backdrop-blur-sm border border-cyan-400/20 rounded-full px-6 py-3">
              <Zap className="h-5 w-5 text-cyan-400 animate-pulse" />
              <span className="text-cyan-300 font-medium">Advanced Technology</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-black mb-6 bg-gradient-to-r from-white via-cyan-200 to-blue-200 bg-clip-text text-transparent">
              Why Choose Rental Guide MY?
            </h2>
            <p className="text-xl text-white/70 max-w-3xl mx-auto">
              Advanced AI technology meets comprehensive rental services
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* AI Price Protection */}
            <div className="group relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/10">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="relative z-10">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="p-4 bg-gradient-to-r from-cyan-500/20 to-blue-500/20 rounded-xl group-hover:scale-110 transition-transform duration-300 border border-cyan-400/30">
                    <ShieldCheck className="h-8 w-8 text-cyan-400" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">AI Price Protection</h3>
                    <p className="text-sm text-cyan-300">Misleading listing detection & verification</p>
                  </div>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-center text-sm text-white/80">
                    <CheckCircle className="w-4 h-4 text-cyan-400 mr-3" />
                    Instant price verification
                  </li>
                  <li className="flex items-center text-sm text-white/80">
                    <CheckCircle className="w-4 h-4 text-cyan-400 mr-3" />
                    Misleading listing risk assessment
                  </li>
                  <li className="flex items-center text-sm text-white/80">
                    <CheckCircle className="w-4 h-4 text-cyan-400 mr-3" />
                    Market comparison
                  </li>
                </ul>
              </div>
            </div>

            {/* Smart Analytics */}
            <div className="group relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/10">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-indigo-500/10 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="relative z-10">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="p-4 bg-gradient-to-r from-blue-500/20 to-indigo-500/20 rounded-xl group-hover:scale-110 transition-transform duration-300 border border-blue-400/30">
                    <BarChart3 className="h-8 w-8 text-blue-400" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Smart Analytics</h3>
                    <p className="text-sm text-blue-300">Market insights & trends</p>
                  </div>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-center text-sm text-white/80">
                    <CheckCircle className="w-4 h-4 text-blue-400 mr-3" />
                    Real-time market data
                  </li>
                  <li className="flex items-center text-sm text-white/80">
                    <CheckCircle className="w-4 h-4 text-blue-400 mr-3" />
                    Price trend analysis
                  </li>
                  <li className="flex items-center text-sm text-white/80">
                    <CheckCircle className="w-4 h-4 text-blue-400 mr-3" />
                    Area comparisons
                  </li>
                </ul>
              </div>
            </div>

            {/* Complete Services */}
            <div className="group relative bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 hover:bg-white/10 transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/10">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-pink-500/10 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="relative z-10">
                <div className="flex items-center space-x-4 mb-6">
                  <div className="p-4 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-xl group-hover:scale-110 transition-transform duration-300 border border-purple-400/30">
                    <Package className="h-8 w-8 text-purple-400" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">Complete Services</h3>
                    <p className="text-sm text-purple-300">End-to-end rental solutions</p>
                  </div>
                </div>
                <ul className="space-y-3">
                  <li className="flex items-center text-sm text-white/80">
                    <CheckCircle className="w-4 h-4 text-purple-400 mr-3" />
                    Moving companies
                  </li>
                  <li className="flex items-center text-sm text-white/80">
                    <CheckCircle className="w-4 h-4 text-purple-400 mr-3" />
                    Furniture rental
                  </li>
                  <li className="flex items-center text-sm text-white/80">
                    <CheckCircle className="w-4 h-4 text-purple-400 mr-3" />
                    Internet services
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Complete Move-In Solutions */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Complete Move-In Solutions</h2>
            <p className="text-lg text-gray-600">Everything you need for your new home</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8">
            {/* Moving Services */}
            <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all duration-300 group">
              <div className="flex items-center space-x-4 mb-4">
                <div className="p-3 bg-blue-100 rounded-lg group-hover:scale-110 transition-transform">
                  <Truck className="h-8 w-8 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Moving Services</h3>
                  <p className="text-sm text-gray-600">Professional movers</p>
                </div>
              </div>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center text-sm text-gray-700">
                  <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mr-2"></span>
                  Full-service moving
                </li>
                <li className="flex items-center text-sm text-gray-700">
                  <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mr-2"></span>
                  Packing & unpacking
                </li>
                <li className="flex items-center text-sm text-gray-700">
                  <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mr-2"></span>
                  Insurance coverage
                </li>
                <li className="flex items-center text-sm text-gray-700">
                  <span className="w-1.5 h-1.5 bg-blue-600 rounded-full mr-2"></span>
                  Same-day service
                </li>
              </ul>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                <p className="text-sm font-semibold text-blue-900">🎁 Special Offer</p>
                <p className="text-xs text-blue-700">Free packing materials + 10% off</p>
              </div>
              <Link href="/services?tab=moving" className="btn-primary w-full justify-center">
                Find Movers
              </Link>
            </div>

            {/* Furniture Rental */}
            <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all duration-300 group">
              <div className="flex items-center space-x-4 mb-4">
                <div className="p-3 bg-green-100 rounded-lg group-hover:scale-110 transition-transform">
                  <Home className="h-8 w-8 text-green-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Furniture Rental</h3>
                  <p className="text-sm text-gray-600">Flexible furniture solutions</p>
                </div>
              </div>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center text-sm text-gray-700">
                  <span className="w-1.5 h-1.5 bg-green-600 rounded-full mr-2"></span>
                  Complete home packages
                </li>
                <li className="flex items-center text-sm text-gray-700">
                  <span className="w-1.5 h-1.5 bg-green-600 rounded-full mr-2"></span>
                  Premium furniture
                </li>
                <li className="flex items-center text-sm text-gray-700">
                  <span className="w-1.5 h-1.5 bg-green-600 rounded-full mr-2"></span>
                  Free delivery & setup
                </li>
                <li className="flex items-center text-sm text-gray-700">
                  <span className="w-1.5 h-1.5 bg-green-600 rounded-full mr-2"></span>
                  Monthly contracts
                </li>
              </ul>
              <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                <p className="text-sm font-semibold text-green-900">🎁 Special Offer</p>
                <p className="text-xs text-green-700">First month 50% off</p>
              </div>
              <Link href="/services?tab=furniture" className="btn-primary w-full justify-center bg-green-600 hover:bg-green-700">
                Rent Furniture
              </Link>
            </div>

            {/* Internet Services */}
            <div className="bg-white rounded-xl p-6 shadow-md hover:shadow-xl transition-all duration-300 group">
              <div className="flex items-center space-x-4 mb-4">
                <div className="p-3 bg-indigo-100 rounded-lg group-hover:scale-110 transition-transform">
                  <Wifi className="h-8 w-8 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900">Internet Services</h3>
                  <p className="text-sm text-gray-600">High-speed fibre broadband</p>
                </div>
              </div>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center text-sm text-gray-700">
                  <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full mr-2"></span>
                  TIME, Maxis, Unifi & More
                </li>
                <li className="flex items-center text-sm text-gray-700">
                  <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full mr-2"></span>
                  100 Mbps to 2 Gbps Plans
                </li>
                <li className="flex items-center text-sm text-gray-700">
                  <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full mr-2"></span>
                  Free Installation & Router
                </li>
                <li className="flex items-center text-sm text-gray-700">
                  <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full mr-2"></span>
                  Fast Setup (2-7 Days)
                </li>
              </ul>
              <div className="bg-indigo-50 border border-indigo-200 rounded-lg p-3 mb-4">
                <p className="text-sm font-semibold text-indigo-900">🎁 Special Offer</p>
                <p className="text-xs text-indigo-700">Free router + cashback deals</p>
              </div>
              <Link href="/services?tab=internet" className="btn-primary w-full justify-center bg-indigo-600 hover:bg-indigo-700">
                Compare Internet Plans
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-b from-slate-900 to-black text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/5 to-blue-500/5" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-10 h-10 bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-500/25">
                  <Brain className="h-6 w-6 text-white" />
                </div>
                <span className="text-2xl font-bold bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-400 bg-clip-text text-transparent">
                  Rental Guide MY
                </span>
              </div>
              <p className="text-white/70 leading-relaxed">
                AI-powered rental intelligence for Malaysia. Protect yourself from misleading listings with advanced price verification.
              </p>
            </div>
            <div>
              <h3 className="font-bold mb-6 text-cyan-300">Quick Links</h3>
              <ul className="space-y-3">
                <li><Link href="/" className="text-white/70 hover:text-cyan-400 transition-all duration-300 hover:translate-x-1 inline-block">Quick Check</Link></li>
                <li><Link href="/verify" className="text-white/70 hover:text-cyan-400 transition-all duration-300 hover:translate-x-1 inline-block">Verify Listing</Link></li>
                <li><Link href="/compare" className="text-white/70 hover:text-cyan-400 transition-all duration-300 hover:translate-x-1 inline-block">Compare</Link></li>
                <li><Link href="/trends" className="text-white/70 hover:text-cyan-400 transition-all duration-300 hover:translate-x-1 inline-block">Trends</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-6 text-blue-300">Services</h3>
              <ul className="space-y-3">
                <li><Link href="/services?tab=moving" className="text-white/70 hover:text-blue-400 transition-all duration-300 hover:translate-x-1 inline-block">Moving</Link></li>
                <li><Link href="/services?tab=furniture" className="text-white/70 hover:text-blue-400 transition-all duration-300 hover:translate-x-1 inline-block">Furniture</Link></li>
                <li><Link href="/services?tab=internet" className="text-white/70 hover:text-blue-400 transition-all duration-300 hover:translate-x-1 inline-block">Internet</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="font-bold mb-6 text-purple-300">Support</h3>
              <ul className="space-y-3">
                <li><Link href="/about" className="text-white/70 hover:text-purple-400 transition-all duration-300 hover:translate-x-1 inline-block">About</Link></li>
                <li><a href="#" className="text-white/70 hover:text-purple-400 transition-all duration-300 hover:translate-x-1 inline-block">Contact</a></li>
                <li><a href="#" className="text-white/70 hover:text-purple-400 transition-all duration-300 hover:translate-x-1 inline-block">Privacy</a></li>
                <li><a href="#" className="text-white/70 hover:text-purple-400 transition-all duration-300 hover:translate-x-1 inline-block">Terms</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 mt-12 pt-8 text-center">
            <p className="text-white/60">&copy; 2024 Rental Guide MY. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
