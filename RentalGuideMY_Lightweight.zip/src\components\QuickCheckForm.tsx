"use client"

import { useMutation } from "@tanstack/react-query"
import { useState } from "react"
import { postJSON } from "@/lib/api"
import { formatMYR } from "@/lib/money"
import { MapPin, Loader2, AlertCircle, CheckCircle } from "lucide-react"

type EstimateIn = {
  lat: number
  lng: number
  area_m2: number
  beds: number
  baths: number
  property_type: string
  furnished: string
  area: string
}

type ListingOut = {
  id: string
  source: string
  url?: string
  address?: string
  area_m2?: number
  beds?: number
  asking_rent?: number
  property_type?: string
}

type EstimateOut = {
  estimate: number
  low: number
  high: number
  model_version: string
  comps: ListingOut[]
  data_recency: string
  comps_count: number
}

const DEFAULTS: EstimateIn = {
  lat: 3.1390,
  lng: 101.6869,
  area_m2: 80,
  beds: 2,
  baths: 2,
  property_type: "condominium",
  furnished: "fully_furnished",
  area: "kuala_lumpur"
}

export default function QuickCheckForm() {
  const [formData, setFormData] = useState<EstimateIn>(DEFAULTS)
  const [address, setAddress] = useState("")
  const [isGeocoding, setIsGeocoding] = useState(false)

  const estimateMut = useMutation({
    mutationFn: async (payload: EstimateIn): Promise<EstimateOut> => {
      return postJSON<EstimateOut>("/estimate", payload)
    },
  })

  const handleGeocode = async () => {
    if (!address.trim()) return

    setIsGeocoding(true)
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(address)}&countrycodes=my&limit=1`
      )
      const data = await response.json()
      
      if (data.length > 0) {
        const result = data[0]
        setFormData(prev => ({
          ...prev,
          lat: parseFloat(result.lat),
          lng: parseFloat(result.lon)
        }))
      }
    } catch (error) {
      console.error("Geocoding failed:", error)
    } finally {
      setIsGeocoding(false)
    }
  }

  const updateField = (key: keyof EstimateIn, value: any) => {
    setFormData(prev => ({ ...prev, [key]: value }))
  }

  const convertSqFtToM2 = (sqft: number) => sqft * 0.092903
  const convertM2ToSqFt = (m2: number) => m2 / 0.092903

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    estimateMut.mutate(formData)
  }

  const getConfidenceTier = (compsCount: number) => {
    if (compsCount >= 10) return "High"
    if (compsCount >= 5) return "Medium"
    return "Low"
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <div className="bg-white rounded-xl shadow-lg p-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Smart Rental Market Analysis</h2>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Address Input */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Property Address
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                className="input flex-1"
                placeholder="Enter property address (e.g., Mont Kiara, Kuala Lumpur)"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
              />
              <button
                type="button"
                onClick={handleGeocode}
                disabled={isGeocoding || !address.trim()}
                className="btn-secondary flex items-center gap-2"
              >
                {isGeocoding ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <MapPin className="h-4 w-4" />
                )}
                {isGeocoding ? "Finding..." : "Find"}
              </button>
            </div>
          </div>

          {/* Property Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Area
              </label>
              <select
                className="input w-full"
                value={formData.area}
                onChange={(e) => updateField('area', e.target.value)}
              >
                <option value="kuala_lumpur">Kuala Lumpur</option>
                <option value="selangor">Selangor</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Property Type
              </label>
              <select
                className="input w-full"
                value={formData.property_type}
                onChange={(e) => updateField('property_type', e.target.value)}
              >
                <option value="condominium">Condominium</option>
                <option value="serviced_residences">Serviced Residences</option>
                <option value="bungalow">Bungalow</option>
                <option value="link_terrace_house">Link/Terrace House</option>
                <option value="semi_detached_house">Semi Detached House</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Built Up (sq. ft.)
              </label>
              <input
                type="number"
                className="input w-full"
                value={Math.round(convertM2ToSqFt(formData.area_m2))}
                onChange={(e) => updateField('area_m2', convertSqFtToM2(Number(e.target.value)))}
                min="1"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Bedrooms
              </label>
              <input
                type="number"
                className="input w-full"
                value={formData.beds}
                onChange={(e) => updateField('beds', Number(e.target.value))}
                min="1"
                max="10"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Bathrooms
              </label>
              <input
                type="number"
                className="input w-full"
                value={formData.baths}
                onChange={(e) => updateField('baths', Number(e.target.value))}
                min="1"
                max="10"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Furnishing
              </label>
              <select
                className="input w-full"
                value={formData.furnished}
                onChange={(e) => updateField('furnished', e.target.value)}
              >
                <option value="fully_furnished">Fully Furnished</option>
                <option value="partial_furnished">Partial Furnished</option>
                <option value="unfurnished">Unfurnished</option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            disabled={estimateMut.isPending}
            className="btn-primary w-full text-lg py-3"
          >
            {estimateMut.isPending ? (
              <>
                <Loader2 className="inline-block mr-2 h-5 w-5 animate-spin" />
                Analyzing...
              </>
            ) : (
              "Get Estimate"
            )}
          </button>
        </form>

        {/* Results */}
        {estimateMut.isError && (
          <div className="mt-6 p-4 bg-red-50 border border-red-200 rounded-lg">
            <div className="flex items-center">
              <AlertCircle className="h-5 w-5 text-red-500 mr-2" />
              <span className="text-red-700">
                {estimateMut.error?.message || "Failed to get estimate. Please try again."}
              </span>
            </div>
            <button
              onClick={() => estimateMut.reset()}
              className="mt-2 text-sm text-red-600 hover:text-red-800 underline"
            >
              Try Again
            </button>
          </div>
        )}

        {estimateMut.isSuccess && estimateMut.data && (
          <div className="mt-8 space-y-6">
            {/* Estimate Results */}
            <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-200">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Rental Estimate</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-sm text-gray-600">Low Range</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {formatMYR(estimateMut.data.low)}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600">Estimate</p>
                  <p className="text-3xl font-bold text-indigo-600">
                    {formatMYR(estimateMut.data.estimate)}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600">High Range</p>
                  <p className="text-2xl font-bold text-blue-600">
                    {formatMYR(estimateMut.data.high)}
                  </p>
                </div>
              </div>
              
              <div className="mt-4 flex items-center justify-center space-x-4 text-sm text-gray-600">
                <span>Confidence: {getConfidenceTier(estimateMut.data.comps_count)}</span>
                <span>•</span>
                <span>Model: {estimateMut.data.model_version}</span>
                <span>•</span>
                <span>Data: {estimateMut.data.data_recency}</span>
              </div>
            </div>

            {/* Comparable Properties */}
            {estimateMut.data.comps.length > 0 ? (
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">
                  Comparable Properties ({estimateMut.data.comps.length})
                </h3>
                <div className="space-y-3">
                  {estimateMut.data.comps.slice(0, 10).map((comp, idx) => (
                    <div key={comp.id} className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="text-sm font-medium text-gray-900">{comp.address}</span>
                            <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                              {comp.source}
                            </span>
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <span>{comp.beds} beds</span>
                            <span>•</span>
                            <span>{Math.round(convertM2ToSqFt(comp.area_m2 || 0))} sq ft</span>
                            <span>•</span>
                            <span>{comp.property_type}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-semibold text-gray-900">
                            {comp.asking_rent ? formatMYR(comp.asking_rent) : "N/A"}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-center">
                  <AlertCircle className="h-5 w-5 text-yellow-500 mr-2" />
                  <span className="text-yellow-700">
                    Limited data nearby—range widened
                  </span>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
