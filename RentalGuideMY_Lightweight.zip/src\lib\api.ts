// Declare process for TypeScript
declare const process: {
  env: {
    NEXT_PUBLIC_API_BASE?: string;
  };
};

const getBaseURL = () => {
  return process.env.NEXT_PUBLIC_API_BASE || 'http://localhost:8000'
}

export async function postJSON<T>(endpoint: string, data: any): Promise<T> {
  const response = await fetch(`${getBaseURL()}${endpoint}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`)
  }

  return response.json()
}

export async function get<T>(endpoint: string): Promise<T> {
  const response = await fetch(`${getBaseURL()}${endpoint}`)
  
  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`)
  }

  return response.json()
}

export async function post<T>(endpoint: string, data: any): Promise<T> {
  return postJSON<T>(endpoint, data)
}

export async function put<T>(endpoint: string, data: any): Promise<T> {
  const response = await fetch(`${getBaseURL()}${endpoint}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`)
  }

  return response.json()
}

export async function del<T>(endpoint: string): Promise<T> {
  const response = await fetch(`${getBaseURL()}${endpoint}`, {
    method: 'DELETE',
  })

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`)
  }

  return response.json()
}

export async function uploadFile<T>(endpoint: string, file: File): Promise<T> {
  const formData = new FormData()
  formData.append('file', file)

  const response = await fetch(`${getBaseURL()}${endpoint}`, {
    method: 'POST',
    body: formData,
  })

  if (!response.ok) {
    throw new Error(`HTTP error! status: ${response.status}`)
  }

  return response.json()
}

export async function healthCheck(): Promise<{ status: string; timestamp: string }> {
  return get<{ status: string; timestamp: string }>('/health')
}

export function setAuthToken(token: string) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('auth_token', token)
  }
}

export function clearAuthToken() {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('auth_token')
  }
}

export function getAuthToken(): string | null {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('auth_token')
  }
  return null
}

export async function searchAreas(query: string, limit: number = 10) {
  return get<{ areas: Array<{ id: string; name: string; type: string }> }>(`/areas/search?query=${encodeURIComponent(query)}&limit=${limit}`)
}

export async function submitQuoteRequest(payload: any) {
  return postJSON<any>('/quote-request', payload)
}