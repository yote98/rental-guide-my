/** @type {import('next').NextConfig} */
const nextConfig = {
  // Clean config: Next.js 14 uses the app directory by default, no need for experimental.appDir.
}

module.exports = nextConfig
