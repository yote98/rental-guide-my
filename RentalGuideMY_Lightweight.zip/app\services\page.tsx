"use client"

import { useState, useEffect } from 'react'
import { Truck, Home, Wifi, Star, CheckCircle, Phone, Mail, MapPin, Calendar, Package, Shield, Clock } from 'lucide-react'
import { formatMYR } from '@/lib/money'

type ServiceProvider = {
  id: string
  name: string
  type: 'moving' | 'furniture' | 'internet'
  rating: number
  reviews: number
  price_range: string
  features: string[]
  contact: {
    phone: string
    email: string
    website: string
  }
  special_offers: string[]
  coverage_areas: string[]
}

const MOCK_PROVIDERS: ServiceProvider[] = [
  // Moving Services
  {
    id: 'mover_1',
    name: 'KL Professional Movers',
    type: 'moving',
    rating: 4.8,
    reviews: 234,
    price_range: 'RM 200-500',
    features: ['Full-service moving', 'Packing & unpacking', 'Insurance coverage', 'Same-day service'],
    contact: {
      phone: '+60 12-345-6789',
      email: 'info@klmovers.com',
      website: 'www.klmovers.com'
    },
    special_offers: ['Free packing materials', '10% off first move'],
    coverage_areas: ['Kuala Lumpur', 'Selangor', 'Putrajaya']
  },
  {
    id: 'mover_2',
    name: 'Swift Relocations',
    type: 'moving',
    rating: 4.6,
    reviews: 189,
    price_range: 'RM 150-400',
    features: ['Local & interstate', 'Furniture disassembly', 'Storage solutions', '24/7 support'],
    contact: {
      phone: '+60 12-987-6543',
      email: 'hello@swiftrelo.com',
      website: 'www.swiftrelo.com'
    },
    special_offers: ['Free consultation', 'Same-day quotes'],
    coverage_areas: ['Kuala Lumpur', 'Selangor', 'Penang', 'Johor']
  },
  
  // Furniture Rental
  {
    id: 'furniture_1',
    name: 'FurniFlex Malaysia',
    type: 'furniture',
    rating: 4.7,
    reviews: 156,
    price_range: 'RM 500-2000/month',
    features: ['Complete home packages', 'Premium furniture', 'Free delivery & setup', 'Flexible contracts'],
    contact: {
      phone: '+60 12-456-7890',
      email: 'rentals@furniflex.com',
      website: 'www.furniflex.com'
    },
    special_offers: ['First month 50% off', 'Free maintenance'],
    coverage_areas: ['Kuala Lumpur', 'Selangor', 'Petaling Jaya']
  },
  {
    id: 'furniture_2',
    name: 'HomeStyle Rentals',
    type: 'furniture',
    rating: 4.5,
    reviews: 98,
    price_range: 'RM 300-1500/month',
    features: ['Modern furniture', 'Quick delivery', 'Monthly contracts', 'Easy returns'],
    contact: {
      phone: '+60 12-789-0123',
      email: 'info@homestyle.com',
      website: 'www.homestyle.com'
    },
    special_offers: ['No deposit required', 'Free setup'],
    coverage_areas: ['Kuala Lumpur', 'Selangor']
  },
  
  // Internet Services
  {
    id: 'internet_1',
    name: 'TIME Internet',
    type: 'internet',
    rating: 4.4,
    reviews: 312,
    price_range: 'RM 99-299/month',
    features: ['100 Mbps to 1 Gbps', 'Free installation', '24/7 support', 'WiFi router included'],
    contact: {
      phone: '+60 3-1234-5678',
      email: 'sales@time.com.my',
      website: 'www.time.com.my'
    },
    special_offers: ['Free router', 'First month free'],
    coverage_areas: ['Kuala Lumpur', 'Selangor', 'Penang', 'Johor']
  },
  {
    id: 'internet_2',
    name: 'Maxis Home Fibre',
    type: 'internet',
    rating: 4.6,
    reviews: 445,
    price_range: 'RM 89-399/month',
    features: ['Up to 2 Gbps', 'Free installation', 'Premium router', 'Mobile data bundle'],
    contact: {
      phone: '+60 12-300-1234',
      email: 'home@maxis.com.my',
      website: 'www.maxis.com.my'
    },
    special_offers: ['Cashback deals', 'Free mobile data'],
    coverage_areas: ['Kuala Lumpur', 'Selangor', 'Penang', 'Johor', 'Sabah', 'Sarawak']
  }
]

export default function ServicesPage() {
  const [activeTab, setActiveTab] = useState<'moving' | 'furniture' | 'internet'>('moving')
  const [providers, setProviders] = useState<ServiceProvider[]>([])

  useEffect(() => {
    const filtered = MOCK_PROVIDERS.filter(p => p.type === activeTab)
    setProviders(filtered)
  }, [activeTab])

  const getTabIcon = (type: string) => {
    switch (type) {
      case 'moving': return <Truck className="h-5 w-5" />
      case 'furniture': return <Home className="h-5 w-5" />
      case 'internet': return <Wifi className="h-5 w-5" />
      default: return null
    }
  }

  const getTabTitle = (type: string) => {
    switch (type) {
      case 'moving': return 'Moving Services'
      case 'furniture': return 'Furniture Rental'
      case 'internet': return 'Internet Services'
      default: return ''
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <Package className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">Rental Guide MY</span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="/" className="text-gray-700 hover:text-blue-600 transition-colors">Quick Check</a>
              <a href="/verify" className="text-gray-700 hover:text-blue-600 transition-colors">Verify</a>
              <a href="/compare" className="text-gray-700 hover:text-blue-600 transition-colors">Compare</a>
              <a href="/services" className="text-blue-600 font-semibold">Services</a>
              <a href="/trends" className="text-gray-700 hover:text-blue-600 transition-colors">Trends</a>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Complete Move-In Solutions
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Everything you need for your new home. Professional services with verified providers.
          </p>
        </div>

        {/* Service Tabs */}
        <div className="flex justify-center mb-8">
          <div className="bg-white rounded-xl p-2 shadow-lg">
            {(['moving', 'furniture', 'internet'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-lg transition-all duration-200 ${
                  activeTab === tab
                    ? 'bg-blue-600 text-white shadow-md'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                {getTabIcon(tab)}
                <span className="font-medium">{getTabTitle(tab)}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Service Providers */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {providers.map((provider) => (
            <div key={provider.id} className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{provider.name}</h3>
                  <div className="flex items-center space-x-2 mb-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(provider.rating)
                              ? 'text-yellow-400 fill-current'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600">
                      {provider.rating} ({provider.reviews} reviews)
                    </span>
                  </div>
                  <p className="text-lg font-semibold text-blue-600">{provider.price_range}</p>
                </div>
                <div className="text-right">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    <Shield className="h-3 w-3 mr-1" />
                    Verified
                  </span>
                </div>
              </div>

              <div className="mb-4">
                <h4 className="font-medium text-gray-900 mb-2">Features</h4>
                <div className="flex flex-wrap gap-2">
                  {provider.features.map((feature, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center px-2 py-1 rounded-md text-xs bg-blue-100 text-blue-800"
                    >
                      <CheckCircle className="h-3 w-3 mr-1" />
                      {feature}
                    </span>
                  ))}
                </div>
              </div>

              {provider.special_offers.length > 0 && (
                <div className="mb-4">
                  <h4 className="font-medium text-gray-900 mb-2">Special Offers</h4>
                  <div className="space-y-1">
                    {provider.special_offers.map((offer, idx) => (
                      <div key={idx} className="flex items-center text-sm text-green-700">
                        <span className="w-1.5 h-1.5 bg-green-500 rounded-full mr-2"></span>
                        {offer}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="mb-4">
                <h4 className="font-medium text-gray-900 mb-2">Coverage Areas</h4>
                <div className="flex flex-wrap gap-1">
                  {provider.coverage_areas.map((area, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center px-2 py-1 rounded-md text-xs bg-gray-100 text-gray-700"
                    >
                      <MapPin className="h-3 w-3 mr-1" />
                      {area}
                    </span>
                  ))}
                </div>
              </div>

              <div className="border-t border-gray-200 pt-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                  <div className="flex items-center text-sm text-gray-600">
                    <Phone className="h-4 w-4 mr-2" />
                    <span className="truncate">{provider.contact.phone}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Mail className="h-4 w-4 mr-2" />
                    <span className="truncate">{provider.contact.email}</span>
                  </div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Clock className="h-4 w-4 mr-2" />
                    <span>24/7 Support</span>
                  </div>
                </div>
                
                <div className="flex space-x-3">
                  <button className="btn-primary flex-1 justify-center">
                    Get Quote
                  </button>
                  <button className="btn-secondary flex-1 justify-center">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action */}
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-8 text-center text-white">
          <h2 className="text-2xl font-bold mb-4">Need Help Choosing?</h2>
          <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
            Our AI-powered recommendation engine can help you find the perfect service providers 
            based on your specific needs and location.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-white text-blue-600 hover:bg-gray-100 font-semibold py-3 px-6 rounded-lg transition-colors duration-200">
              Get AI Recommendations
            </button>
            <button className="border-2 border-white text-white hover:bg-white hover:text-blue-600 font-semibold py-3 px-6 rounded-lg transition-colors duration-200">
              Contact Support
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
