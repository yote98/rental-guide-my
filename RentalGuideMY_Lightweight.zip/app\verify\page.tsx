"use client"

import { useState } from 'react'
import { ShieldCheck, AlertTriangle, CheckCircle, Loader2, ExternalLink, MapPin, DollarSign, Calendar, Home } from 'lucide-react'
import { postJSON } from '@/lib/api'
import { formatMYR } from '@/lib/money'

type VerificationRequest = {
  listing_url: string
  asking_rent: number
  address: string
  area_m2: number
  beds: number
  baths: number
  property_type: string
  furnished: boolean
}

type VerificationResult = {
  is_legitimate: boolean
  risk_score: number
  price_analysis: {
    estimated_range: {
      low: number
      high: number
    }
    market_position: string
    price_vs_market: number
  }
  red_flags: string[]
  green_flags: string[]
  recommendations: string[]
  comparable_properties: Array<{
    id: string
    address: string
    asking_rent: number
    area_m2: number
    beds: number
    source: string
    url?: string
  }>
}

export default function VerifyPage() {
  const [formData, setFormData] = useState<VerificationRequest>({
    listing_url: '',
    asking_rent: 0,
    address: '',
    area_m2: 0,
    beds: 0,
    baths: 0,
    property_type: 'condominium',
    furnished: false
  })
  const [isVerifying, setIsVerifying] = useState(false)
  const [result, setResult] = useState<VerificationResult | null>(null)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsVerifying(true)
    setError(null)
    setResult(null)

    try {
      // Mock verification result for demo
      const mockResult: VerificationResult = {
        is_legitimate: Math.random() > 0.3, // 70% chance of being legitimate
        risk_score: Math.floor(Math.random() * 40) + 20, // 20-60 risk score
        price_analysis: {
          estimated_range: {
            low: formData.asking_rent * 0.8,
            high: formData.asking_rent * 1.2
          },
          market_position: formData.asking_rent > 3000 ? 'Premium' : 'Standard',
          price_vs_market: Math.floor(Math.random() * 40) - 20 // -20% to +20%
        },
        red_flags: formData.asking_rent < 1000 ? ['Suspiciously low price'] : [],
        green_flags: ['Property details match market standards', 'Reasonable price range'],
        recommendations: [
          'Verify landlord identity',
          'Request property viewing',
          'Check rental agreement terms'
        ],
        comparable_properties: [
          {
            id: 'comp_1',
            address: 'Similar area property',
            asking_rent: formData.asking_rent * (0.9 + Math.random() * 0.2),
            area_m2: formData.area_m2,
            beds: formData.beds,
            source: 'PropertyGuru'
          }
        ]
      }
      
      setResult(mockResult)
    } catch (err) {
      setError('Verification failed. Please try again.')
    } finally {
      setIsVerifying(false)
    }
  }

  const getRiskColor = (score: number) => {
    if (score < 30) return 'text-green-600'
    if (score < 60) return 'text-yellow-600'
    return 'text-red-600'
  }

  const getRiskLabel = (score: number) => {
    if (score < 30) return 'Low Risk'
    if (score < 60) return 'Medium Risk'
    return 'High Risk'
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <ShieldCheck className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">Rental Guide MY</span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="/" className="text-gray-700 hover:text-blue-600 transition-colors">Quick Check</a>
              <a href="/verify" className="text-blue-600 font-semibold">Verify</a>
              <a href="/compare" className="text-gray-700 hover:text-blue-600 transition-colors">Compare</a>
              <a href="/services" className="text-gray-700 hover:text-blue-600 transition-colors">Services</a>
              <a href="/trends" className="text-gray-700 hover:text-blue-600 transition-colors">Trends</a>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            AI-Powered Listing Verification
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Protect yourself from rental scams with our advanced AI verification system. 
            Get instant analysis of any rental listing.
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-lg p-8 mb-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Listing URL (Optional)
              </label>
              <input
                type="url"
                className="input w-full"
                placeholder="https://propertyguru.com.my/property/..."
                value={formData.listing_url}
                onChange={(e) => setFormData(prev => ({ ...prev, listing_url: e.target.value }))}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Property Address
                </label>
                <input
                  type="text"
                  className="input w-full"
                  placeholder="e.g., Mont Kiara, Kuala Lumpur"
                  value={formData.address}
                  onChange={(e) => setFormData(prev => ({ ...prev, address: e.target.value }))}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Asking Rent (RM)
                </label>
                <input
                  type="number"
                  className="input w-full"
                  placeholder="3000"
                  value={formData.asking_rent || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, asking_rent: Number(e.target.value) }))}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Area (sq ft)
                </label>
                <input
                  type="number"
                  className="input w-full"
                  placeholder="800"
                  value={Math.round(formData.area_m2 / 0.092903) || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, area_m2: Number(e.target.value) * 0.092903 }))}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Property Type
                </label>
                <select
                  className="input w-full"
                  value={formData.property_type}
                  onChange={(e) => setFormData(prev => ({ ...prev, property_type: e.target.value }))}
                >
                  <option value="condominium">Condominium</option>
                  <option value="serviced_residences">Serviced Residences</option>
                  <option value="bungalow">Bungalow</option>
                  <option value="link_terrace_house">Link/Terrace House</option>
                  <option value="semi_detached_house">Semi Detached House</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Bedrooms
                </label>
                <input
                  type="number"
                  className="input w-full"
                  placeholder="2"
                  value={formData.beds || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, beds: Number(e.target.value) }))}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Bathrooms
                </label>
                <input
                  type="number"
                  className="input w-full"
                  placeholder="2"
                  value={formData.baths || ''}
                  onChange={(e) => setFormData(prev => ({ ...prev, baths: Number(e.target.value) }))}
                  required
                />
              </div>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="furnished"
                className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                checked={formData.furnished}
                onChange={(e) => setFormData(prev => ({ ...prev, furnished: e.target.checked }))}
              />
              <label htmlFor="furnished" className="ml-2 text-sm text-gray-700">
                Fully Furnished
              </label>
            </div>

            <button
              type="submit"
              disabled={isVerifying}
              className="btn-primary w-full text-lg py-3"
            >
              {isVerifying ? (
                <>
                  <Loader2 className="inline-block mr-2 h-5 w-5 animate-spin" />
                  Verifying...
                </>
              ) : (
                <>
                  <ShieldCheck className="inline-block mr-2 h-5 w-5" />
                  Verify Listing
                </>
              )}
            </button>
          </form>
        </div>

        {/* Results */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-8">
            <div className="flex items-center">
              <AlertTriangle className="h-5 w-5 text-red-500 mr-2" />
              <span className="text-red-700">{error}</span>
            </div>
          </div>
        )}

        {result && (
          <div className="space-y-6">
            {/* Verification Status */}
            <div className={`rounded-xl p-6 ${result.is_legitimate ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'}`}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  {result.is_legitimate ? (
                    <CheckCircle className="h-8 w-8 text-green-600 mr-3" />
                  ) : (
                    <AlertTriangle className="h-8 w-8 text-red-600 mr-3" />
                  )}
                  <div>
                    <h3 className="text-xl font-semibold text-gray-900">
                      {result.is_legitimate ? 'Listing Appears Legitimate' : 'Potential Issues Detected'}
                    </h3>
                    <p className="text-sm text-gray-600">
                      Risk Score: <span className={`font-semibold ${getRiskColor(result.risk_score)}`}>
                        {result.risk_score}/100 - {getRiskLabel(result.risk_score)}
                      </span>
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Price Analysis */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Price Analysis</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-sm text-gray-600">Estimated Range</p>
                  <p className="text-lg font-semibold text-gray-900">
                    {formatMYR(result.price_analysis.estimated_range.low)} - {formatMYR(result.price_analysis.estimated_range.high)}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600">Market Position</p>
                  <p className="text-lg font-semibold text-gray-900">{result.price_analysis.market_position}</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-600">vs Market</p>
                  <p className={`text-lg font-semibold ${result.price_analysis.price_vs_market > 0 ? 'text-red-600' : 'text-green-600'}`}>
                    {result.price_analysis.price_vs_market > 0 ? '+' : ''}{result.price_analysis.price_vs_market}%
                  </p>
                </div>
              </div>
            </div>

            {/* Flags */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {result.red_flags.length > 0 && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                  <h4 className="font-semibold text-red-900 mb-2 flex items-center">
                    <AlertTriangle className="h-5 w-5 mr-2" />
                    Red Flags
                  </h4>
                  <ul className="space-y-1">
                    {result.red_flags.map((flag, idx) => (
                      <li key={idx} className="text-sm text-red-700">• {flag}</li>
                    ))}
                  </ul>
                </div>
              )}

              {result.green_flags.length > 0 && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <h4 className="font-semibold text-green-900 mb-2 flex items-center">
                    <CheckCircle className="h-5 w-5 mr-2" />
                    Green Flags
                  </h4>
                  <ul className="space-y-1">
                    {result.green_flags.map((flag, idx) => (
                      <li key={idx} className="text-sm text-green-700">• {flag}</li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Recommendations */}
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2">Recommendations</h4>
              <ul className="space-y-1">
                {result.recommendations.map((rec, idx) => (
                  <li key={idx} className="text-sm text-blue-700">• {rec}</li>
                ))}
              </ul>
            </div>

            {/* Comparable Properties */}
            {result.comparable_properties.length > 0 && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Similar Properties</h3>
                <div className="space-y-3">
                  {result.comparable_properties.map((prop) => (
                    <div key={prop.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="font-medium text-gray-900">{prop.address}</span>
                            <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                              {prop.source}
                            </span>
                          </div>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            <span>{prop.beds} beds</span>
                            <span>•</span>
                            <span>{Math.round(prop.area_m2 / 0.092903)} sq ft</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-lg font-semibold text-gray-900">
                            {formatMYR(prop.asking_rent)}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
