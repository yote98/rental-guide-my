"use client"

import { useState, useEffect } from 'react'
import { Search, MapPin, Home, DollarSign, Star, TrendingUp, TrendingDown, BarChart3, CheckCircle, AlertTriangle } from 'lucide-react'
import { formatMYR } from '@/lib/money'

type PropertyComparison = {
  id: string
  address: string
  area_m2: number
  beds: number
  baths: number
  asking_rent: number
  property_type: string
  furnished: boolean
  source: string
  url?: string
  features: string[]
  amenities: string[]
  distance_to_klcc: number
  walkability_score: number
  public_transport_score: number
}

const MOCK_PROPERTIES: PropertyComparison[] = [
  {
    id: 'prop_1',
    address: 'Mont Kiara, Kuala Lumpur',
    area_m2: 85,
    beds: 2,
    baths: 2,
    asking_rent: 3500,
    property_type: 'condominium',
    furnished: true,
    source: 'PropertyGuru',
    url: 'https://propertyguru.com.my/property/123',
    features: ['Swimming Pool', 'Gym', 'Security', 'Parking'],
    amenities: ['Shopping Mall', 'Restaurants', 'Hospital'],
    distance_to_klcc: 8.5,
    walkability_score: 7,
    public_transport_score: 6
  },
  {
    id: 'prop_2',
    address: 'Bangsar, Kuala Lumpur',
    area_m2: 75,
    beds: 2,
    baths: 2,
    asking_rent: 3200,
    property_type: 'condominium',
    furnished: false,
    source: 'iProperty',
    url: 'https://iproperty.com.my/property/456',
    features: ['Swimming Pool', 'Gym', 'Security'],
    amenities: ['Shopping Mall', 'Restaurants', 'Park'],
    distance_to_klcc: 6.2,
    walkability_score: 8,
    public_transport_score: 8
  },
  {
    id: 'prop_3',
    address: 'KLCC, Kuala Lumpur',
    area_m2: 90,
    beds: 2,
    baths: 2,
    asking_rent: 4200,
    property_type: 'condominium',
    furnished: true,
    source: 'PropertyGuru',
    url: 'https://propertyguru.com.my/property/789',
    features: ['Swimming Pool', 'Gym', 'Security', 'Parking', 'Concierge'],
    amenities: ['Shopping Mall', 'Restaurants', 'Office Buildings'],
    distance_to_klcc: 0.5,
    walkability_score: 9,
    public_transport_score: 9
  }
]

export default function ComparePage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedProperties, setSelectedProperties] = useState<string[]>([])
  const [properties, setProperties] = useState<PropertyComparison[]>(MOCK_PROPERTIES)
  const [filteredProperties, setFilteredProperties] = useState<PropertyComparison[]>(MOCK_PROPERTIES)

  useEffect(() => {
    const filtered = properties.filter(prop =>
      prop.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      prop.property_type.toLowerCase().includes(searchQuery.toLowerCase())
    )
    setFilteredProperties(filtered)
  }, [searchQuery, properties])

  const togglePropertySelection = (propertyId: string) => {
    setSelectedProperties(prev => {
      if (prev.includes(propertyId)) {
        return prev.filter(id => id !== propertyId)
      } else if (prev.length < 3) {
        return [...prev, propertyId]
      }
      return prev
    })
  }

  const getSelectedPropertiesData = () => {
    return selectedProperties.map(id => 
      properties.find(prop => prop.id === id)
    ).filter(Boolean) as PropertyComparison[]
  }

  const getBestValue = () => {
    const selected = getSelectedPropertiesData()
    if (selected.length === 0) return null
    
    return selected.reduce((best, current) => {
      const currentValue = current.asking_rent / current.area_m2
      const bestValue = best.asking_rent / best.area_m2
      return currentValue < bestValue ? current : best
    })
  }

  const getMostExpensive = () => {
    const selected = getSelectedPropertiesData()
    if (selected.length === 0) return null
    
    return selected.reduce((most, current) => 
      current.asking_rent > most.asking_rent ? current : most
    )
  }

  const getCheapest = () => {
    const selected = getSelectedPropertiesData()
    if (selected.length === 0) return null
    
    return selected.reduce((cheapest, current) => 
      current.asking_rent < cheapest.asking_rent ? current : cheapest
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <BarChart3 className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">Rental Guide MY</span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="/" className="text-gray-700 hover:text-blue-600 transition-colors">Quick Check</a>
              <a href="/verify" className="text-gray-700 hover:text-blue-600 transition-colors">Verify</a>
              <a href="/compare" className="text-blue-600 font-semibold">Compare</a>
              <a href="/services" className="text-gray-700 hover:text-blue-600 transition-colors">Services</a>
              <a href="/trends" className="text-gray-700 hover:text-blue-600 transition-colors">Trends</a>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Compare Rental Properties
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Compare up to 3 properties side-by-side to make the best rental decision
          </p>
        </div>

        {/* Search */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="flex items-center space-x-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                <input
                  type="text"
                  className="input pl-10"
                  placeholder="Search properties by location or type..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>
            <div className="text-sm text-gray-600">
              {selectedProperties.length}/3 selected
            </div>
          </div>
        </div>

        {/* Property Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          {filteredProperties.map((property) => (
            <div
              key={property.id}
              className={`bg-white rounded-xl shadow-lg p-6 cursor-pointer transition-all duration-200 ${
                selectedProperties.includes(property.id)
                  ? 'ring-2 ring-blue-500 shadow-xl'
                  : 'hover:shadow-xl'
              }`}
              onClick={() => togglePropertySelection(property.id)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    checked={selectedProperties.includes(property.id)}
                    onChange={() => togglePropertySelection(property.id)}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                  />
                  <span className="ml-2 text-sm font-medium text-gray-700">
                    {selectedProperties.includes(property.id) ? 'Selected' : 'Select'}
                  </span>
                </div>
                <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                  {property.source}
                </span>
              </div>

              <div className="mb-4">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{property.address}</h3>
                <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                  <span>{property.beds} beds</span>
                  <span>•</span>
                  <span>{property.baths} baths</span>
                  <span>•</span>
                  <span>{Math.round(property.area_m2 / 0.092903)} sq ft</span>
                </div>
                <p className="text-2xl font-bold text-blue-600">{formatMYR(property.asking_rent)}</p>
              </div>

              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-600">
                  <MapPin className="h-4 w-4 mr-2" />
                  {property.distance_to_klcc}km to KLCC
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Walkability: {property.walkability_score}/10
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Home className="h-4 w-4 mr-2" />
                  {property.furnished ? 'Furnished' : 'Unfurnished'}
                </div>
              </div>

              {property.features.length > 0 && (
                <div className="mt-4">
                  <div className="flex flex-wrap gap-1">
                    {property.features.slice(0, 3).map((feature, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center px-2 py-1 rounded-md text-xs bg-blue-100 text-blue-800"
                      >
                        {feature}
                      </span>
                    ))}
                    {property.features.length > 3 && (
                      <span className="text-xs text-gray-500">
                        +{property.features.length - 3} more
                      </span>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Comparison Results */}
        {selectedProperties.length > 0 && (
          <div className="space-y-8">
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Comparison Results</h2>
              
              {/* Quick Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <h3 className="text-sm font-medium text-gray-600 mb-2">Best Value</h3>
                  <p className="text-lg font-semibold text-green-600">
                    {getBestValue()?.address}
                  </p>
                  <p className="text-sm text-gray-600">
                    {getBestValue() && formatMYR(getBestValue()!.asking_rent / getBestValue()!.area_m2)}/sq ft
                  </p>
                </div>
                <div className="text-center p-4 bg-red-50 rounded-lg">
                  <h3 className="text-sm font-medium text-gray-600 mb-2">Most Expensive</h3>
                  <p className="text-lg font-semibold text-red-600">
                    {getMostExpensive()?.address}
                  </p>
                  <p className="text-sm text-gray-600">
                    {getMostExpensive() && formatMYR(getMostExpensive()!.asking_rent)}
                  </p>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <h3 className="text-sm font-medium text-gray-600 mb-2">Cheapest</h3>
                  <p className="text-lg font-semibold text-blue-600">
                    {getCheapest()?.address}
                  </p>
                  <p className="text-sm text-gray-600">
                    {getCheapest() && formatMYR(getCheapest()!.asking_rent)}
                  </p>
                </div>
              </div>

              {/* Detailed Comparison Table */}
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200">
                      <th className="text-left py-3 px-4 font-semibold text-gray-900">Property</th>
                      {getSelectedPropertiesData().map((property) => (
                        <th key={property.id} className="text-center py-3 px-4 font-semibold text-gray-900">
                          {property.address}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    <tr>
                      <td className="py-3 px-4 font-medium text-gray-700">Rent</td>
                      {getSelectedPropertiesData().map((property) => (
                        <td key={property.id} className="text-center py-3 px-4">
                          <span className="text-lg font-semibold text-gray-900">
                            {formatMYR(property.asking_rent)}
                          </span>
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-medium text-gray-700">Size</td>
                      {getSelectedPropertiesData().map((property) => (
                        <td key={property.id} className="text-center py-3 px-4">
                          {Math.round(property.area_m2 / 0.092903)} sq ft
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-medium text-gray-700">Price per sq ft</td>
                      {getSelectedPropertiesData().map((property) => (
                        <td key={property.id} className="text-center py-3 px-4">
                          {formatMYR(property.asking_rent / (property.area_m2 / 0.092903))}
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-medium text-gray-700">Distance to KLCC</td>
                      {getSelectedPropertiesData().map((property) => (
                        <td key={property.id} className="text-center py-3 px-4">
                          {property.distance_to_klcc}km
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-medium text-gray-700">Walkability</td>
                      {getSelectedPropertiesData().map((property) => (
                        <td key={property.id} className="text-center py-3 px-4">
                          <div className="flex items-center justify-center">
                            <span className="text-sm font-medium text-gray-900 mr-2">
                              {property.walkability_score}/10
                            </span>
                            <div className="w-16 bg-gray-200 rounded-full h-2">
                              <div
                                className="bg-blue-600 h-2 rounded-full"
                                style={{ width: `${(property.walkability_score / 10) * 100}%` }}
                              ></div>
                            </div>
                          </div>
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-medium text-gray-700">Public Transport</td>
                      {getSelectedPropertiesData().map((property) => (
                        <td key={property.id} className="text-center py-3 px-4">
                          <div className="flex items-center justify-center">
                            <span className="text-sm font-medium text-gray-900 mr-2">
                              {property.public_transport_score}/10
                            </span>
                            <div className="w-16 bg-gray-200 rounded-full h-2">
                              <div
                                className="bg-green-600 h-2 rounded-full"
                                style={{ width: `${(property.public_transport_score / 10) * 100}%` }}
                              ></div>
                            </div>
                          </div>
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-medium text-gray-700">Furnished</td>
                      {getSelectedPropertiesData().map((property) => (
                        <td key={property.id} className="text-center py-3 px-4">
                          <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                            property.furnished 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-gray-100 text-gray-800'
                          }`}>
                            {property.furnished ? 'Yes' : 'No'}
                          </span>
                        </td>
                      ))}
                    </tr>
                    <tr>
                      <td className="py-3 px-4 font-medium text-gray-700">Features</td>
                      {getSelectedPropertiesData().map((property) => (
                        <td key={property.id} className="text-center py-3 px-4">
                          <div className="flex flex-wrap gap-1 justify-center">
                            {property.features.slice(0, 2).map((feature, idx) => (
                              <span
                                key={idx}
                                className="inline-flex items-center px-2 py-1 rounded-md text-xs bg-blue-100 text-blue-800"
                              >
                                {feature}
                              </span>
                            ))}
                            {property.features.length > 2 && (
                              <span className="text-xs text-gray-500">
                                +{property.features.length - 2}
                              </span>
                            )}
                          </div>
                        </td>
                      ))}
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

            {/* Recommendations */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 rounded-xl p-8 text-white">
              <h2 className="text-2xl font-bold mb-4">AI Recommendations</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Best Overall Choice</h3>
                  <p className="text-blue-100">
                    Based on price, location, and amenities, we recommend the property that offers 
                    the best value for your budget and lifestyle needs.
                  </p>
                </div>
                <div>
                  <h3 className="text-lg font-semibold mb-2">Considerations</h3>
                  <ul className="text-blue-100 space-y-1">
                    <li>• Factor in transportation costs</li>
                    <li>• Check for hidden fees</li>
                    <li>• Verify amenities availability</li>
                    <li>• Consider future resale value</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Empty State */}
        {selectedProperties.length === 0 && (
          <div className="text-center py-12">
            <BarChart3 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No Properties Selected</h3>
            <p className="text-gray-600 mb-6">
              Select up to 3 properties to compare their features, pricing, and amenities.
            </p>
            <button
              onClick={() => setSearchQuery('')}
              className="btn-primary"
            >
              Browse Properties
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
