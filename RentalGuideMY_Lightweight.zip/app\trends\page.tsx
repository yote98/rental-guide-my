"use client"

import { useState, useEffect } from 'react'
import { TrendingUp, TrendingDown, BarChart3, MapPin, Calendar, DollarSign, Home, Filter } from 'lucide-react'
import { formatMYR } from '@/lib/money'

type TrendData = {
  month: string
  median_rent: number
  count: number
  price_change: number
}

type AreaTrends = {
  area_name: string
  property_type: string
  trends: TrendData[]
  summary: {
    current_median: number
    year_change: number
    market_activity: string
    price_trend: 'up' | 'down' | 'stable'
  }
}

const MOCK_TRENDS: AreaTrends[] = [
  {
    area_name: 'Kuala Lumpur',
    property_type: 'condominium',
    trends: [
      { month: '2024-01', median_rent: 3200, count: 45, price_change: 2.1 },
      { month: '2024-02', median_rent: 3350, count: 52, price_change: 4.7 },
      { month: '2024-03', median_rent: 3400, count: 48, price_change: 1.5 },
      { month: '2024-04', median_rent: 3450, count: 41, price_change: 1.5 },
      { month: '2024-05', median_rent: 3500, count: 38, price_change: 1.4 },
      { month: '2024-06', median_rent: 3550, count: 44, price_change: 1.4 }
    ],
    summary: {
      current_median: 3550,
      year_change: 10.9,
      market_activity: 'High',
      price_trend: 'up'
    }
  },
  {
    area_name: 'Mont Kiara',
    property_type: 'condominium',
    trends: [
      { month: '2024-01', median_rent: 4200, count: 23, price_change: 1.2 },
      { month: '2024-02', median_rent: 4350, count: 28, price_change: 3.6 },
      { month: '2024-03', median_rent: 4400, count: 25, price_change: 1.1 },
      { month: '2024-04', median_rent: 4450, count: 22, price_change: 1.1 },
      { month: '2024-05', median_rent: 4500, count: 19, price_change: 1.1 },
      { month: '2024-06', median_rent: 4550, count: 24, price_change: 1.1 }
    ],
    summary: {
      current_median: 4550,
      year_change: 8.3,
      market_activity: 'Medium',
      price_trend: 'up'
    }
  },
  {
    area_name: 'Bangsar',
    property_type: 'condominium',
    trends: [
      { month: '2024-01', median_rent: 2800, count: 18, price_change: -0.5 },
      { month: '2024-02', median_rent: 2850, count: 22, price_change: 1.8 },
      { month: '2024-03', median_rent: 2900, count: 20, price_change: 1.8 },
      { month: '2024-04', median_rent: 2950, count: 17, price_change: 1.7 },
      { month: '2024-05', median_rent: 3000, count: 15, price_change: 1.7 },
      { month: '2024-06', median_rent: 3050, count: 19, price_change: 1.7 }
    ],
    summary: {
      current_median: 3050,
      year_change: 8.9,
      market_activity: 'Medium',
      price_trend: 'up'
    }
  }
]

export default function TrendsPage() {
  const [selectedArea, setSelectedArea] = useState('Kuala Lumpur')
  const [selectedPropertyType, setSelectedPropertyType] = useState('condominium')
  const [trendsData, setTrendsData] = useState<AreaTrends | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    const fetchTrends = async () => {
      setIsLoading(true)
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000))
      
      const data = MOCK_TRENDS.find(t => 
        t.area_name === selectedArea && t.property_type === selectedPropertyType
      ) || MOCK_TRENDS[0]
      
      setTrendsData(data)
      setIsLoading(false)
    }

    fetchTrends()
  }, [selectedArea, selectedPropertyType])

  const getTrendIcon = (trend: 'up' | 'down' | 'stable') => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-5 w-5 text-green-600" />
      case 'down': return <TrendingDown className="h-5 w-5 text-red-600" />
      case 'stable': return <BarChart3 className="h-5 w-5 text-gray-600" />
    }
  }

  const getTrendColor = (trend: 'up' | 'down' | 'stable') => {
    switch (trend) {
      case 'up': return 'text-green-600'
      case 'down': return 'text-red-600'
      case 'stable': return 'text-gray-600'
    }
  }

  const getActivityColor = (activity: string) => {
    switch (activity.toLowerCase()) {
      case 'high': return 'bg-green-100 text-green-800'
      case 'medium': return 'bg-yellow-100 text-yellow-800'
      case 'low': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-lg flex items-center justify-center">
                <BarChart3 className="h-5 w-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900">Rental Guide MY</span>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="/" className="text-gray-700 hover:text-blue-600 transition-colors">Quick Check</a>
              <a href="/verify" className="text-gray-700 hover:text-blue-600 transition-colors">Verify</a>
              <a href="/compare" className="text-gray-700 hover:text-blue-600 transition-colors">Compare</a>
              <a href="/services" className="text-gray-700 hover:text-blue-600 transition-colors">Services</a>
              <a href="/trends" className="text-blue-600 font-semibold">Trends</a>
            </nav>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Rental Market Trends & Analytics
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Stay informed with real-time rental market data and trends across Malaysia
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <MapPin className="inline-block h-4 w-4 mr-1" />
                Area
              </label>
              <select
                className="input w-full"
                value={selectedArea}
                onChange={(e) => setSelectedArea(e.target.value)}
              >
                <option value="Kuala Lumpur">Kuala Lumpur</option>
                <option value="Mont Kiara">Mont Kiara</option>
                <option value="Bangsar">Bangsar</option>
                <option value="Petaling Jaya">Petaling Jaya</option>
                <option value="Subang Jaya">Subang Jaya</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Home className="inline-block h-4 w-4 mr-1" />
                Property Type
              </label>
              <select
                className="input w-full"
                value={selectedPropertyType}
                onChange={(e) => setSelectedPropertyType(e.target.value)}
              >
                <option value="condominium">Condominium</option>
                <option value="serviced_residences">Serviced Residences</option>
                <option value="bungalow">Bungalow</option>
                <option value="link_terrace_house">Link/Terrace House</option>
              </select>
            </div>
          </div>
        </div>

        {/* Loading State */}
        {isLoading && (
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading market trends...</p>
          </div>
        )}

        {/* Trends Data */}
        {trendsData && !isLoading && (
          <div className="space-y-8">
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 bg-blue-100 rounded-lg">
                    <DollarSign className="h-6 w-6 text-blue-600" />
                  </div>
                  <div className="flex items-center">
                    {getTrendIcon(trendsData.summary.price_trend)}
                  </div>
                </div>
                <h3 className="text-sm font-medium text-gray-600 mb-1">Current Median Rent</h3>
                <p className="text-2xl font-bold text-gray-900">{formatMYR(trendsData.summary.current_median)}</p>
                <p className={`text-sm ${getTrendColor(trendsData.summary.price_trend)}`}>
                  {trendsData.summary.year_change > 0 ? '+' : ''}{trendsData.summary.year_change}% vs last year
                </p>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 bg-green-100 rounded-lg">
                    <TrendingUp className="h-6 w-6 text-green-600" />
                  </div>
                </div>
                <h3 className="text-sm font-medium text-gray-600 mb-1">Market Activity</h3>
                <p className="text-2xl font-bold text-gray-900">{trendsData.summary.market_activity}</p>
                <p className="text-sm text-gray-600">Listings available</p>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 bg-purple-100 rounded-lg">
                    <BarChart3 className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
                <h3 className="text-sm font-medium text-gray-600 mb-1">Price Trend</h3>
                <p className="text-2xl font-bold text-gray-900 capitalize">{trendsData.summary.price_trend}</p>
                <p className="text-sm text-gray-600">6-month trend</p>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="p-3 bg-orange-100 rounded-lg">
                    <Calendar className="h-6 w-6 text-orange-600" />
                  </div>
                </div>
                <h3 className="text-sm font-medium text-gray-600 mb-1">Data Points</h3>
                <p className="text-2xl font-bold text-gray-900">{trendsData.trends.length}</p>
                <p className="text-sm text-gray-600">Months tracked</p>
              </div>
            </div>

            {/* Trend Chart */}
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Rental Price Trends</h3>
              <div className="space-y-4">
                {trendsData.trends.map((trend, idx) => (
                  <div key={trend.month} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="text-sm font-medium text-gray-600 w-20">
                        {new Date(trend.month).toLocaleDateString('en-MY', { month: 'short', year: 'numeric' })}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="text-lg font-semibold text-gray-900">
                            {formatMYR(trend.median_rent)}
                          </span>
                          <span className={`text-sm font-medium ${
                            trend.price_change > 0 ? 'text-green-600' : 
                            trend.price_change < 0 ? 'text-red-600' : 'text-gray-600'
                          }`}>
                            {trend.price_change > 0 ? '+' : ''}{trend.price_change}%
                          </span>
                        </div>
                        <div className="text-sm text-gray-600">
                          {trend.count} listings
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {trend.price_change > 0 ? (
                        <TrendingUp className="h-4 w-4 text-green-600" />
                      ) : trend.price_change < 0 ? (
                        <TrendingDown className="h-4 w-4 text-red-600" />
                      ) : (
                        <BarChart3 className="h-4 w-4 text-gray-600" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Market Insights */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Market Insights</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">Best Time to Rent</span>
                    <span className="text-sm font-semibold text-blue-600">Q1-Q2</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">Price Stability</span>
                    <span className="text-sm font-semibold text-green-600">High</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
                    <span className="text-sm font-medium text-gray-700">Competition Level</span>
                    <span className="text-sm font-semibold text-yellow-600">Medium</span>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-4">Recommendations</h3>
                <div className="space-y-3">
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-2"></div>
                    <p className="text-sm text-gray-700">
                      Consider renting in {trendsData.area_name} for competitive pricing
                    </p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-green-600 rounded-full mt-2"></div>
                    <p className="text-sm text-gray-700">
                      Market shows {trendsData.summary.price_trend} trend with {trendsData.summary.market_activity.toLowerCase()} activity
                    </p>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-purple-600 rounded-full mt-2"></div>
                    <p className="text-sm text-gray-700">
                      Monitor price changes monthly for optimal timing
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
